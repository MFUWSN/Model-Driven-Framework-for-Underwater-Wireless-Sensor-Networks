

	
					if (sinkNode-> GetObject<SocketFactory> ID=0)
					{
						Ptr<PacketSocketFactory> SocketPointer = createobject <PacketSocketFactory> ();
        				sinkNode->AggregateObject (SocketPointer);
					}

						 Ptr<Socket> sinkSocket = Socket::createsocket  (sinkNode, ID);
	

