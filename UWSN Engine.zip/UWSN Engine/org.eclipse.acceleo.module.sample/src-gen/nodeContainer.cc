
void 
Verification Setup :: UpdatePositions( NodeContainer nodes )

{

	DEBUG ( Simulator :: Now () . GetSeconds() << "Updating positions") ; 
	NodeContainer :: Iterator it = nodes . Begin ();
	Ptr<UniformRandomVariable> uv = CreateObject<UniformRandomVariable> ();
	for (; it != nodes. End (); it++)
	{
	 Ptr < MobilityModel > MobilityPointer = (*it) -> GetObject < MobilityModel > ();
MobilityPointer -> SetPosition (Vector (uv -> GetValue (0, boundary ), uv->GetValue (0,boundary ), 70.0)); 

	}

}

