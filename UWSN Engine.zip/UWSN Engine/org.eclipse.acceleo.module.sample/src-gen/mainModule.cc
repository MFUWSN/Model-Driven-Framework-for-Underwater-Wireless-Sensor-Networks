
Int MainModule (int argc, char **argv)
{

	ComponentEnable ("UanCwExample", LOG_LEVEL_ALL);

	Verification Setup exp; 



	CommandLine cmd;
	cmd.AddValue ("NumNodes", "Number of transmitting nodes", exp.numNodes);

	cmd.AddValue ("Depth", "Depth of transmitting and sink nodes", exp.depth);

	cmd.AddValue ("RegionSize", "Size of boundary in meters", exp.boundary);

	cmd.AddValue ("PacketSize", "Generated packet size in bytes", exp.packetSize);

	cmd.AddValue ("DataRate", "DataRate in bps", exp.dataRate);

	cmd.AddValue ("CwMin", "Min CW to simulate", exp.cwMin);

	cmd.AddValue ("CwMax", "Max CW to simulate", exp.cwMax);

	cmd.AddValue ("SlotTime", "Slot time duration", exp.slotTime);

	cmd.AddValue ("Averages", "Number of topologies to test for each cw point", exp.avgs);

	cmd.AddValue ("GnuFile", "Name for GNU Plot output", exp.gnudatfile);

	cmd.AddValue ("PerModel", "PER model name", perModel);

	cmd.AddValue ("SinrModel", "SINR model name", sinrModel);

	cmd.Parse (argc, argv);

	ObjectFactory obf;
	obf.SetTypeId (perModel);
 	Ptr<UanPhyPer> per = obf.Create <UanPhyPer> ();
	obf.SetTypeId (sinrModel);
 	Ptr<UanPhyCalcSinr> sinr = obf.Create <UanPhyCalcSinr> ();

	UanHelper uan;
	UanTxMode mode;
	mode = UanTxModeFactory :: CreateMode (UanTxMode::FSK, exp.m_dataRate,
											exp.dataRate, 12000,
											exp.dataRate, 2,
											"Default mode");

	ModesList myModes;
	myModes = AppendMode (mode);

	uan.SetPhy ("ns3::UanPhyGen",
   				"PerModel", PointerValue (per),
                "SinrModel", PointerValue (sinr),
               "SupportedModes", UanModesListValue (myModes));

	Gnuplot gp;
	Gnuplot ds;
	ds = exp.Run (uan);

	gp.AddDataset (ds);

	std::ofstream of (exp.m_gnudatfile.c_str ());

 	per = 0;
	sinr = 0;
}
