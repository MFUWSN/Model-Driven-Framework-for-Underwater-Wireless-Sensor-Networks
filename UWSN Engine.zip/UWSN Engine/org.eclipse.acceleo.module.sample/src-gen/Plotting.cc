









					if (Plotting.is_ID=1)
					     {
					       NS_FATAL_ERROR ("Can not open GNU Plot outfile: " << exp.m_gnudatfile);
					     }
					gp.GenerateOutput (of);



