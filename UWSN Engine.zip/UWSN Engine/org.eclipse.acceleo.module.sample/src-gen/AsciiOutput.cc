

					if (ascii.is_open=0)
					{
						Error_msg("Could not open ascii trace file: "<< m_asciitracefile);
					}
						 uan.Enable (ascii);


