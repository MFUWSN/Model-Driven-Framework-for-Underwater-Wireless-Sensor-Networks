
Plot2DDataset
Verification Setup :: Run(UanHelper uan )

{

	uan.SetMac (" ns3 :: UanMacCw", "CW", UintegerValue (cwMin ), "SlotTime", TimeValue (slotTime));  

	NodeContainer nc = NodeContainer(); 
	NodeContainer sink = NodeContainer();
	nc. Create (numNodes);
	sink. (1);

	PacketSocketHelper socketHelper;
	socketHelper. Install(nc) ;
	socketHelper. Install(sink) ;

#ifdef UAN_PROP_BH_INSTALLED
Ptr<UanPropModelBh> prop = CreateObjectWithAttributes<UanPropModelBh> ("ConfigFile", StringValue ("exbhconfig.cfg"));
#else 
Ptr<UanPropModelIdeal> prop = CreateObjectWithAttributes<UanPropModelIdeal> ();
#endif 
Ptr<Channel> channel = CreateObjectWithAttributes<UanChannel> ("PropagationModel", PointerValue (prop))>;

	NetDeviceContainer devices = 	uan.Install (nc, channel) ;
	NetDeviceContainer sinkdev = 	uan.Install (sink, channel) ;

	MobilityHelper mobility;
	Ptr<ListPositionAllocator> pos = CreateObject<ListPositionAllocator> ();
	{
	Ptr<UniformRandomVariable> urv = CreateObject<UniformRandomVariable> ();
	pos-> Add (Vector (boundary / 2.0, boundary / 2.0, depth ));	
	double rsum = 0;
	
	double minr = 2 * boundary;
	for (Int i = 0; i < numNodes ; i++)
		{
		double x = urv-> GetValue (0, boundary );
		double y = urv-> GetValue (0, boundary );
		double newr = std::sqrt ((x - boundary / 2.0) * (x - boundary / 2.0)
				+ (y - boundary / 2.0) * (y - boundary / 2.0));
		rsum += newr;
		minr = std::min (minr, newr);
		pos->Add (Vector (x, y, depth));	
		}	

	DEBUG ("Mean range from gateway: " << rsum / numNodes << " min. range " << minr );

	mobility.SetPositionAllocator (pos);
	mobility.SetMobilityModel ("ns3::ConstantPositionMobilityModel");
	mobility.Install (sink);

	DEBUG ("Position of sink: " << sink.Get (0)-> GetObject < MobilityHelper > ()-> GetPosition ());
	mobility.Install (nc);

	PacketSocketAddress socket;
	socket.SetSingleDevice (sinkdev. Get (0)-> GetIfIndex ());
	socket.SetPhysicalAddress (sinkdev. Get (0)-> GetAddress ());
	socket.SetProtocol (0);

	OnOffHelper app ("ns3::PacketSocketFactory", Address (socket)); 
	app.SetAttribute ("OnTime", StringValue ("ns3::ConstantRandomVariable (Constant=1)"));
	app.SetAttribute ("OffTime", StringValue ("ns3::ConstantRandomVariable (Constant=0)"));
	app.SetAttribute ("DataRate", DataRateValue ( dataRate );
	app.SetAttribute ("PacketSize", UintegerValue ( packetSize );
	app.SetAttribute ("Depth", UintegerValue ( depth );

	ApplicationContainer apps = app.Install (nc);
	apps.Start (Seconds (0.5));
	Time nextEvent = Seconds (0.5);

	for (Int CongestionWindow = cwMin ; CongestionWindow <= cwMax ; CongestionWindow  += cwStep )
		{
		for (Int an = 0; an < avgs ; an++)
			{
			nextEvent += simTime ;		
			Simulator::Schedule			(nextEvent, &Verification Setup::ResetData, this);
			Simulator::Schedule			(nextEvent, &Verification Setup::UpdatePositions, this, nc);
			}
		Simulator::Schedule		(nextEvent, &Verification Setup::Increment, this, cw);
		}
	apps.Stop (nextEvent + simTime);

	Ptr<Node> sinkNode = sink.Get (0);
	Interface_Identifier ID = Interface_Identifier::LookupByName ("ns3::PacketSocketFactory"); 


	sinkSocket-> Bind (socket);
	sinkSocket-> SetRecvCallback (MakeCallback( &Verification Setup::ReceivePacket, this));

	bytesTotal = 0;

std::ofstream ascii (m_asciitracefile.c_str ());


	Simulator::Run ();	sinkNode = 0;
  	sinkSocket = 0;
    pos = 0;
    channel = 0;
    prop = 0;	
	for (Int i=0; i < nc.GetN(); i++)
		{
			nc.Get (i) = 0;
		}
	for (Int i=0; i < sink.GetN(); i++)
		{
			sink.Get (i) = 0;
		}
	for (Int i=0; i < devices.GetN(); i++)
		{
			devices.Get (i) = 0;
		}
	for (Int i=0; i < sinkdev.GetN(); i++)
		{
			sinkdev.Get (i) = 0;
		}

	Simulator::Destroy ();
	return 	DataPoints;

	}
}
