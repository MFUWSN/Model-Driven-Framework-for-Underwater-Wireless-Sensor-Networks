
#ifndef UAN_CW_EXAMPLE_H
#define UAN_CW_EXAMPLE_H
#include "ns3/network-module.h"
#include "ns3/stats-module.h"
#include "ns3/uan-module.h" 
using namespace ns3;
class Verification Setup {
public:

	Plot2DDataset Run(UanHelper uan );	
	void UpdatePositions(NodeContainer nodes );
	void ResetData();
	void Increment( CongestionWindow );
	VerificationSetup();			


		 numNodes;				

		 dataRate;				

		 depth;				

		 boundary;				

		 packetSize;				

		 bytesTotal;				

		 cwMin;				

		 cwMax;				

		 cwStep;				

		 avgs;				

		Time slotTime;				

		Time simTime;				

		 gnudatfile;				

		 asciitracefile;				

		 bhCfgFile;				

		std::vector<double> throughputs;

	Plot2DDataset DataPoints;				 	

}


Verification Setup :: VerificationSetup() 
:
	numNodes ( 15 ) ,
	dataRate ( 80 ) ,
	depth ( 70.0 ) ,
	boundary ( 500.0 ) ,
	packetSize ( 32 ) ,
	bytesTotal ( 0 ) ,
	cwMin ( 10 ) ,
	cwMax ( 400 ) ,
	cwStep ( 10 ) ,
	avgs ( 3 ) ,
	slotTime ( 0.2 ) ,
	simTime ( 1000 ) ,
	gnudatfile ( uan-cw-example.gpl ) ,
	asciitracefile ( uan-cw-example.asc ) ,
	bhCfgFile ( uan-apps/dat/default.cfg ) ,

{
}

