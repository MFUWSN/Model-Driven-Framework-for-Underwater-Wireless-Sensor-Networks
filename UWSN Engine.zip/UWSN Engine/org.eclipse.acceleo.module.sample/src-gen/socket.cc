
void 
Verification Setup :: ReceivePacket( Ptr < Socket > socket )

{

Ptr < Packet > packet ;
While ( ( packet  = socket -> Recv() ) )
{
bytesTotal + = packet ->  GetSize () ; 

}
 packet = 0;  

}

