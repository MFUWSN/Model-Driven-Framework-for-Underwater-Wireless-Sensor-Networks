include "uan-cw-example.h"
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/mobility-module.h"
#include "ns3/stats-module.h"
#include "ns3/applications-module.h"
#include <fstream>
using namespace ns3;

void 
Verification Setup :: ResetData()

{

	DEBUG(Simulator::Now().GetSeconds()<< "Resetting data"); 
	throughputs.push_back(bytesTotal * 8.0 / simTime.    GetSeconds()); 
	bytesTotal=0;

}


void
Verification Setup :: Increment( CongestionWindow )

{

ASSERT	(throughputs.size()== avgs);
avgThroughput=0;
	DataPoints.Add(CongestionWindow,avgThroughput);
throughputs.Clear();
	Config::Set ("/NodeList/*/DeviceList/*/Mac/CW", UintegerValue (CongestionWindow + cwStep));
	SeedManager :: SetRun(SeedManager :: GetRun()+ 1)

}

